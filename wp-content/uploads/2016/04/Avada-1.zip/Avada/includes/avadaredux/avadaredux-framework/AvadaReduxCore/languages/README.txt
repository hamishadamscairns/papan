Please visit: https://github.com/AvadaReduxFramework/AvadaReduxFramework/wiki/Translate for details on how you can help.
